<?php
############################################################################
# FANTACALCIOBAZAR EVOLUTION
# Copyright (C) 2003-2010 by Antonello Onida
#
# PARAMETRI VISUALIZZAZIONE ED ESTETICA

$news_per_pagina				    = '3';
$n_ultime_notizie 				= '10';
$commenti_fb 					= 'NO';
$like_fb 						= 'NO';
$dim_comm_fb 						= '400';
# PARAMETRI NON CONFIGURABILI DA FORM

$archivio_dati = 'csvfile'; #csvfile o mysql
$notizie_file = './dati/notizie_file.csv';
$pagine_file = './dati/pagine_file.csv';
$categorie_file = './dati/categorie_file.csv';
$sottocategorie_file = './dati/sottocategorie_file.csv';
$mostra_calendario = 'NO';
$mostra_gall_index = 'SI';
$data_mod = time();
?>