<?php
#
# Configurazione CMS Alessia edit 6/2/2007
#

$data_mod					= gmmktime();
$archivio_dati 			= 'csvfile';					 # opzioni mysql o csvfile
$notizie_file   			= './dati/notizie_file.csv';
$pagine_file	 			= './dati/pagine_file.csv';
$categorie_file			= './dati/categorie_file.csv';
$sottocategorie_file		= './dati/sottocategorie_file.csv';
$news_per_pagina			= '3';
$n_ultime_notizie			= '10'; 
$mostra_calendario 		= 'NO';
$mostra_gall_index 		= 'SI';
$commenti_fb				= "NO";
$like_fb						= "NO";	# solo se commenti == NO
$dim_comm_fb				= "400";

/* MySQL Server (per $archivio dati = "mysql")
$db_server      = '';
$db_login       = '';
$db_database    = '';
$db_password    = '';
*/

?>