<?php
$voti_consentiti = '0';
$voto_palese = 'NO';
$domanda = 'Test';
$opzioni = array('Prima','Seconda','Seconda','Terza');
$voti_Test = array();
$voti_ = array();
$voti1 = 0;
$voti2 = 0;
$voti3 = 0;
$voti4 = 0;
?>